#!/bin/bash

export PYTHONPATH=~/python-chord/
echo $PYTHONPATH

python3 ./as4.py $@


